
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Census</title>
	<link rel="stylesheet" type="text/css" href="">
    </head>
    <body>
      <div id="app"></div>


      <?php echo app('Illuminate\Foundation\Vite')('resources/js/main.js'); ?>


    </body>
</html>
<?php /**PATH /home/abel/Desktop/backend/backend-cen/resources/views/welcome.blade.php ENDPATH**/ ?>